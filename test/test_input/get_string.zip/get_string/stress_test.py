
import random
import string

# Sizes in MB to test
sizes_mb = [1, 10, 100]

def generate_test_files():
    for size in sizes_mb:
        num_chars = size * 1024 * 1024  # size in chars

        # 1. Repeated 'A'
        with open(f"repeat_A_{size}MB.txt", "w", encoding="utf-8") as f:
            f.write("A" * num_chars)

        # 2. Whitespace only (but no newlines, just spaces and tabs)
        with open(f"whitespace_{size}MB.txt", "w", encoding="utf-8") as f:
            pattern = " \t"
            repeated = (pattern * (num_chars // len(pattern) + 1))[:num_chars]
            f.write(repeated)

        # 3. Unicode chaos (no newlines)
        with open(f"unicode_{size}MB.txt", "w", encoding="utf-8") as f:
            symbols = "🚀🌌🔥💀💡✨🐉🐍🔢"
            repeated = (symbols * (num_chars // len(symbols) + 1))[:num_chars]
            f.write(repeated)

        # 4. Alternating AB
        with open(f"alternating_AB_{size}MB.txt", "w", encoding="utf-8") as f:
            pattern = "AB"
            repeated = (pattern * (num_chars // len(pattern) + 1))[:num_chars]
            f.write(repeated)

        # 5. Random ASCII (excluding newline)
        safe_ascii = string.printable.replace("\n", "").replace("\r", "")
        with open(f"random_ascii_{size}MB.txt", "w", encoding="utf-8") as f:
            random_chars = ''.join(random.choices(safe_ascii, k=num_chars))
            f.write(random_chars)

if __name__ == "__main__":
    generate_test_files()
    print("Done! Test files generated (no newlines).")
